import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2'; 

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
};
const httpOptionsJson = {
  headers: new HttpHeaders({ 'Content-Type': "application/json;charset=utf-8" })
};
const httpOptionsFiles = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};

@Injectable()
export class CommonService {
  APIUrl: string;
  id:string;
  public alerts: Array<IAlert> = [];
  public darkAlerts: Array<IAlert> = [];
  title = '';
  message = '';
  type = 'success';
  tapToDismiss = true;
  closeButton = false;
  progressBar = false;
  preventDuplicates = false;
  newestOnTop = false;
  progressAnimation = 'decreasing';
  positionClass = 'toast-top-right';
  curMsgIndex = -1;
  token: string;
  constructor(private http: HttpClient, public toastrService: ToastrService, private titleService: Title, private router: Router) {
    this.APIUrl = environment.API;
  }

  
  showAlert(title, message, actiontype, url="") {
    if(url != "")
    { 
      Swal.fire({
        title: title,
        text: message,
        type: actiontype,
        showCancelButton: false, 
        confirmButtonColor: '#007f73',
        confirmButtonText: 'Ok',
        }
      ).then(
        (isConfirm) => {
            if(isConfirm.value)
            {
                this.router.navigate([url]);
            }
        }
      );
    }
    else{
      Swal.fire({
        title: title,
        text: message,
        type: actiontype,
        confirmButtonColor: '#007f73',
      })
    }
  }

  

  setAgreementVal(Value)
  {
    this.id = Value;
  }
  
  getAgreementVal()
  { 
    return this.id;
  }

  showToast(message, type) {
    this.message = message;
    this.type = type;
    const options = {
      tapToDismiss: this.tapToDismiss,
      closeButton: this.closeButton,
      progressBar: this.progressBar,
      progressAnimation: this.progressAnimation,
      positionClass: this.positionClass,
      rtl: this.isRTL
    };
    // `newestOnTop` and `preventDuplicates` options must be set on global config
    this.toastrService.toastrConfig.newestOnTop = this.newestOnTop;
    this.toastrService.toastrConfig.preventDuplicates = this.preventDuplicates;
    this.toastrService[this.type](this.message, this.title, options);
  }

  clearToasts() {
    this.toastrService.clear();
  }

  // Set page title
  set pageTitle(value: string) {
    this.titleService.setTitle(`${value}`);
  }

  // Check for RTL layout
  get isRTL() {
    return document.documentElement.getAttribute('dir') === 'rtl' ||
      document.body.getAttribute('dir') === 'rtl';
  }

  // Check if IE10
  get isIE10() {
    return typeof document['documentMode'] === 'number' && document['documentMode'] === 10;
  }

  getData(model, url, mode) {
    let auth_token;
    if (mode == "POST") {
      let body = this.serializeObj(model);
      return this.http.post(this.APIUrl + url, body, httpOptions);
    }
    else if (mode == "JSON") {
      if (url != "Login") {
        return this.http.post(this.APIUrl + url, JSON.stringify(model), { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': auth_token }) });
      }
      else {
        return this.http.post(this.APIUrl + url, JSON.stringify(model), httpOptionsJson);
      }
    }
    else if (mode == "PUT") {
      return this.http.put(this.APIUrl + url, JSON.stringify(model), { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': auth_token }) });
    }
    else if (mode == "DELETE") {
      const httpOptionsNew = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify(model) };
      return this.http.delete(this.APIUrl + url, { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': auth_token }) });
    }
    else if (mode == "GET") {
      return this.http.get(this.APIUrl + url, httpOptions )
    }
    else if (mode == "GETAllowAnon") {
      return this.http.get(this.APIUrl + url, { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': auth_token }) })
    }
  }

  private serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));
    return result.join("&");
  }

}

export interface IAlert {
  id: number;
  type: string;
  message: string;
}
